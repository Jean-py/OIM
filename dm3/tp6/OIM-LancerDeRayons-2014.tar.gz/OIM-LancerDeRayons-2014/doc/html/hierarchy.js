var hierarchy =
[
    [ "Bound_", "a00003.html", null ],
    [ "BSDF", "a00005.html", null ],
    [ "Camera", "a00006.html", null ],
    [ "Color", "a00007.html", null ],
    [ "Diff_Geom", "a00013.html", null ],
    [ "Geometry", "a00014.html", [
      [ "Box3D", "a00004.html", null ],
      [ "Cone", "a00008.html", null ],
      [ "CSGDifference", "a00009.html", null ],
      [ "CSGIntersection", "a00010.html", null ],
      [ "CSGUnion", "a00011.html", null ],
      [ "Cylinder", "a00012.html", null ],
      [ "Plane", "a00024.html", null ],
      [ "Sphere", "a00029.html", null ]
    ] ],
    [ "Image", "a00017.html", null ],
    [ "IntervalSet", "a00018.html", null ],
    [ "Isect", "a00019.html", null ],
    [ "Light", "a00020.html", null ],
    [ "Material", "a00021.html", [
      [ "Glass", "a00015.html", null ],
      [ "Glossy", "a00016.html", null ],
      [ "Matte", "a00022.html", null ],
      [ "Metal", "a00023.html", null ],
      [ "Plastic", "a00025.html", null ]
    ] ],
    [ "Primitive", "a00026.html", null ],
    [ "Ray", "a00027.html", null ],
    [ "Scene", "a00028.html", null ],
    [ "Texture", "a00030.html", null ],
    [ "Vector3D", "a00031.html", null ]
];