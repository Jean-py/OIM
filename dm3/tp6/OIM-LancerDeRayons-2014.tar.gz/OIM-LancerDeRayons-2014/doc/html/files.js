var files =
[
    [ "box.hpp", "a00032.html", null ],
    [ "bsdf.hpp", "a00033.html", null ],
    [ "camera.hpp", "a00034.html", null ],
    [ "color.hpp", "a00035.html", null ],
    [ "cone.hpp", "a00036.html", "a00036" ],
    [ "csg.hpp", "a00037.html", [
      [ "CSGIntersection", "a00010.html", "a00010" ],
      [ "CSGUnion", "a00011.html", "a00011" ],
      [ "CSGDifference", "a00009.html", "a00009" ]
    ] ],
    [ "cylinder.hpp", "a00038.html", null ],
    [ "diff_geom.hpp", "a00039.html", null ],
    [ "geometry.hpp", "a00040.html", null ],
    [ "glass.hpp", "a00041.html", null ],
    [ "glossy.hpp", "a00042.html", null ],
    [ "image.hpp", "a00043.html", "a00043" ],
    [ "intervaloperators.cpp", "a00044.html", "a00044" ],
    [ "intervaloperators.hpp", "a00045.html", "a00045" ],
    [ "intervalset.hpp", "a00046.html", [
      [ "IntervalSet", "a00018.html", "a00018" ]
    ] ],
    [ "isect.hpp", "a00047.html", null ],
    [ "light.hpp", "a00048.html", null ],
    [ "main.cpp", "a00049.html", "a00049" ],
    [ "material.hpp", "a00050.html", null ],
    [ "matte.hpp", "a00051.html", null ],
    [ "metal.hpp", "a00052.html", null ],
    [ "plane.hpp", "a00053.html", null ],
    [ "plastic.hpp", "a00054.html", null ],
    [ "primitive.hpp", "a00055.html", null ],
    [ "ray.hpp", "a00056.html", null ],
    [ "raytracing.cpp", "a00057.html", "a00057" ],
    [ "raytracing.h", "a00058.html", "a00058" ],
    [ "scene.hpp", "a00059.html", null ],
    [ "sphere.hpp", "a00060.html", null ],
    [ "texture.cpp", "a00061.html", null ],
    [ "texture.hpp", "a00062.html", null ],
    [ "texturefetch.cpp", "a00063.html", "a00063" ],
    [ "texturefetch.hpp", "a00064.html", "a00064" ],
    [ "vector3d.hpp", "a00065.html", null ]
];