var a00014 =
[
    [ "clip", "a00014.html#a767321b776e8662e39aa32347e8918ee", null ],
    [ "intersect", "a00014.html#ae992633602643893bbd1e286e2ca98f9", null ],
    [ "settangent", "a00014.html#a7fd58bab5c99530e71757539ee3384a3", null ]
];