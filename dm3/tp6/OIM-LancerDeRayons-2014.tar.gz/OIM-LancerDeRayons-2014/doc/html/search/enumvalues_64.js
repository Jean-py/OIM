var searchData=
[
  ['diffuse',['DIFFUSE',['../a00005.html#a852f0629069a83f4852b3edcd01cf60eaa87f530394aa0ce82a30c78df742f433',1,'BSDF']]]
];
