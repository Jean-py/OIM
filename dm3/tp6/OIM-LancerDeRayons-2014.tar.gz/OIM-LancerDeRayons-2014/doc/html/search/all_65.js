var searchData=
[
  ['evaluate',['evaluate',['../a00005.html#a89754b621acdd482f06a0b11c0ecdf3a',1,'BSDF::evaluate()'],['../a00015.html#a94c040eef9f806af10a25f3bbdd78819',1,'Glass::evaluate()'],['../a00016.html#aa512c7e4d7e7e5f5ae05a3114aaf753e',1,'Glossy::evaluate()'],['../a00021.html#abb68e80a020e81d0130b275203b1680c',1,'Material::evaluate()'],['../a00022.html#a5b3254ffd73cd1f7f574868b10374bf8',1,'Matte::evaluate()'],['../a00023.html#a3c6190f266c9043c8a1cc157e9647780',1,'Metal::evaluate()'],['../a00025.html#a0ab6450feff5ca3f1f4e3527030e20cb',1,'Plastic::evaluate()']]]
];
