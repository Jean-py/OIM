var searchData=
[
  ['g_5fcamera',['g_camera',['../a00057.html#a8ea4ea2eb2676e84509a7f4c5ce43dda',1,'raytracing.cpp']]],
  ['g_5fp_5fimg',['g_p_img',['../a00057.html#adcfc067701db6262297c2bbec15927cd',1,'raytracing.cpp']]],
  ['g_5fscene',['g_scene',['../a00057.html#aab84ef508ba02254f00c7cd02f420b28',1,'raytracing.cpp']]],
  ['gamma',['GAMMA',['../a00075.html#ga8659b9de3e544ff142b153b076f30fd5',1,'image.hpp']]],
  ['geometry',['Geometry',['../a00014.html',1,'']]],
  ['geometry_2ehpp',['geometry.hpp',['../a00040.html',1,'']]],
  ['get_5fclip_5fpoints',['get_clip_points',['../a00008.html#aa000dbdde858b3eb9078fe90d3ec71b2',1,'Cone::get_clip_points()'],['../a00012.html#a646e440049ec43067444b2efa0c6b860',1,'Cylinder::get_clip_points()']]],
  ['get_5fimage_5fresolution',['get_image_resolution',['../a00074.html#ga0a694e21c663d5c72182c15e34118f23',1,'get_image_resolution(int *p_x_res_, int *p_y_res_):&#160;raytracing.cpp'],['../a00074.html#ga0a694e21c663d5c72182c15e34118f23',1,'get_image_resolution(int *p_x_res_, int *p_y_res_):&#160;raytracing.cpp']]],
  ['get_5flight',['get_light',['../a00070.html#gade62171a2f3b305905e5b0ada32357ff',1,'get_light(int i_):&#160;raytracing.cpp'],['../a00070.html#gade62171a2f3b305905e5b0ada32357ff',1,'get_light(int i_):&#160;raytracing.cpp']]],
  ['get_5fperpendicular',['get_perpendicular',['../a00031.html#aa7c8861c8c7389319fadacf955fd8bb9',1,'Vector3D']]],
  ['getclamp',['getclamp',['../a00030.html#a236619967a1c87428f9393d37cc34e31',1,'Texture']]],
  ['getior',['getIor',['../a00005.html#a40748b3fdb9139f3819660637a127172',1,'BSDF']]],
  ['getpixel',['getPixel',['../a00030.html#a15376a1db3093522b4402220b771ad04',1,'Texture']]],
  ['gettexel',['getTexel',['../a00063.html#ad6c74e0d655725b60d1c0ac068664137',1,'getTexel(unsigned char *pixels, int width, int height, int depth, int column, int row):&#160;texturefetch.cpp'],['../a00064.html#ad6c74e0d655725b60d1c0ac068664137',1,'getTexel(unsigned char *pixels, int width, int height, int depth, int column, int row):&#160;texturefetch.cpp']]],
  ['gettexturecolor',['getTextureColor',['../a00021.html#ad292661deaf1ff67911e8f298717aa43',1,'Material']]],
  ['glass',['Glass',['../a00015.html',1,'Glass'],['../a00015.html#ab6ccfb3332ac7a27d4c01e6654ac9b9e',1,'Glass::Glass()']]],
  ['glass_2ehpp',['glass.hpp',['../a00041.html',1,'']]],
  ['glossy',['Glossy',['../a00016.html',1,'Glossy'],['../a00016.html#a99190c0664503299f088fa4a1dd6f413',1,'Glossy::Glossy()'],['../a00005.html#a852f0629069a83f4852b3edcd01cf60ea5af1a05cf55a29813f9fc99f37d17177',1,'BSDF::GLOSSY()']]],
  ['glossy_2ehpp',['glossy.hpp',['../a00042.html',1,'']]]
];
