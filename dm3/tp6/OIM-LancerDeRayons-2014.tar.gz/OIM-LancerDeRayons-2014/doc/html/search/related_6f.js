var searchData=
[
  ['operator_2a',['operator*',['../a00007.html#a925e7fe8e988d80b2f430ac498711a4d',1,'Color']]],
  ['operator_3c_3c',['operator&lt;&lt;',['../a00031.html#a83b2079b7c252487c56037e18621af75',1,'Vector3D']]]
];
