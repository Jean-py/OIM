var searchData=
[
  ['get_5fclip_5fpoints',['get_clip_points',['../a00008.html#aa000dbdde858b3eb9078fe90d3ec71b2',1,'Cone::get_clip_points()'],['../a00012.html#a646e440049ec43067444b2efa0c6b860',1,'Cylinder::get_clip_points()']]],
  ['get_5fimage_5fresolution',['get_image_resolution',['../a00074.html#ga0a694e21c663d5c72182c15e34118f23',1,'get_image_resolution(int *p_x_res_, int *p_y_res_):&#160;raytracing.cpp'],['../a00074.html#ga0a694e21c663d5c72182c15e34118f23',1,'get_image_resolution(int *p_x_res_, int *p_y_res_):&#160;raytracing.cpp']]],
  ['get_5flight',['get_light',['../a00070.html#gade62171a2f3b305905e5b0ada32357ff',1,'get_light(int i_):&#160;raytracing.cpp'],['../a00070.html#gade62171a2f3b305905e5b0ada32357ff',1,'get_light(int i_):&#160;raytracing.cpp']]],
  ['get_5fperpendicular',['get_perpendicular',['../a00031.html#aa7c8861c8c7389319fadacf955fd8bb9',1,'Vector3D']]],
  ['getclamp',['getclamp',['../a00030.html#a236619967a1c87428f9393d37cc34e31',1,'Texture']]],
  ['getior',['getIor',['../a00005.html#a40748b3fdb9139f3819660637a127172',1,'BSDF']]],
  ['getpixel',['getPixel',['../a00030.html#a15376a1db3093522b4402220b771ad04',1,'Texture']]],
  ['gettexel',['getTexel',['../a00063.html#ad6c74e0d655725b60d1c0ac068664137',1,'getTexel(unsigned char *pixels, int width, int height, int depth, int column, int row):&#160;texturefetch.cpp'],['../a00064.html#ad6c74e0d655725b60d1c0ac068664137',1,'getTexel(unsigned char *pixels, int width, int height, int depth, int column, int row):&#160;texturefetch.cpp']]],
  ['gettexturecolor',['getTextureColor',['../a00021.html#ad292661deaf1ff67911e8f298717aa43',1,'Material']]],
  ['glass',['Glass',['../a00015.html#ab6ccfb3332ac7a27d4c01e6654ac9b9e',1,'Glass']]],
  ['glossy',['Glossy',['../a00016.html#a99190c0664503299f088fa4a1dd6f413',1,'Glossy']]]
];
