var searchData=
[
  ['p_5fcamera',['p_camera',['../a00028.html#a0f0b06829d508e600a712244d5ad7dd6',1,'Scene']]],
  ['p_5flights',['p_lights',['../a00028.html#adce64c848c70c77a5ffb822f11a78aae',1,'Scene']]],
  ['p_5fprims',['p_prims',['../a00028.html#a77e742b6abe8cd60df0424d6bae33946',1,'Scene']]],
  ['pixel',['pixel',['../a00017.html#a21a63d2b2768bab69266ca3dab6fb85d',1,'Image::pixel(int i_, int j_) const '],['../a00017.html#aece561e5fef693cca54c18319fc9b967',1,'Image::pixel(int i_, int j_)']]],
  ['plane',['Plane',['../a00024.html',1,'Plane'],['../a00024.html#aa174951fb18c608b8d29cfede77cc0ba',1,'Plane::Plane()']]],
  ['plane_2ehpp',['plane.hpp',['../a00053.html',1,'']]],
  ['plastic',['Plastic',['../a00025.html',1,'Plastic'],['../a00025.html#a277334a36838a4f095280ce928841821',1,'Plastic::Plastic()']]],
  ['plastic_2ehpp',['plastic.hpp',['../a00054.html',1,'']]],
  ['pos',['pos',['../a00013.html#a5fa6ab4c50cd785ab124fcc4b4c1247a',1,'Diff_Geom::pos()'],['../a00020.html#a305715f1db3acf3dbd9dbd54baaa804e',1,'Light::pos()']]],
  ['postprocess',['postProcess',['../a00017.html#ada7c0a4ad2375f07eb946385144ddd00',1,'Image']]],
  ['prefilter',['prefilter',['../a00030.html#a527fed2088b0fdb8b9384c7137623104',1,'Texture']]],
  ['prefiltertexture',['prefilterTexture',['../a00063.html#a2bbce8cb9f75d7bbfc5601b5cf0c1b01',1,'prefilterTexture(unsigned char **imagearray, int width, int height, int depth, int nblevels):&#160;texturefetch.cpp'],['../a00064.html#a2bbce8cb9f75d7bbfc5601b5cf0c1b01',1,'prefilterTexture(unsigned char **imagearray, int width, int height, int depth, int nblevels):&#160;texturefetch.cpp']]],
  ['primitive',['Primitive',['../a00026.html',1,'Primitive'],['../a00026.html#ae6b6e9440d482575d1dcbf77a936c201',1,'Primitive::Primitive()'],['../a00026.html#ab68aaa10dc86a456aab18a0370fa3168',1,'Primitive::Primitive(Geometry *p_geom_, Material *p_mat_)']]],
  ['primitive_2ehpp',['primitive.hpp',['../a00055.html',1,'']]],
  ['propagatedifferentials',['propagateDifferentials',['../a00027.html#a7a88a22aa552960217a82d37b4e4e979',1,'Ray']]],
  ['pscale',['PSCALE',['../a00036.html#ac6cf65cec21b60cdfe31372f3102b97b',1,'cone.hpp']]],
  ['pure_5frefl',['PURE_REFL',['../a00005.html#a852f0629069a83f4852b3edcd01cf60ea92e7ebf798d62551ba2d81f22bbd370e',1,'BSDF']]]
];
