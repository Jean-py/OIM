var searchData=
[
  ['y',['y',['../a00031.html#a1819fd51b78ece8de462d3a2c979111a',1,'Vector3D::y()'],['../a00043.html#a798e4073d613ca5ba9618e1b3253df14',1,'Y():&#160;image.hpp']]],
  ['y_5fres',['y_res',['../a00006.html#a8206d3f96cc607fbd43037ef017defc2',1,'Camera::y_res()'],['../a00017.html#ad6d99103e357656543cf080f22c5858d',1,'Image::y_res()']]]
];
