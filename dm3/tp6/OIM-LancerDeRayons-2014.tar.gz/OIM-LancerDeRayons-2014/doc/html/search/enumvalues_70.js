var searchData=
[
  ['pure_5frefl',['PURE_REFL',['../a00005.html#a852f0629069a83f4852b3edcd01cf60ea92e7ebf798d62551ba2d81f22bbd370e',1,'BSDF']]]
];
