var searchData=
[
  ['clamp',['clamp',['../a00030.html#aca02c9519d137e2262ec48d5057749b8',1,'Texture']]]
];
