var searchData=
[
  ['color_20management_20api',['Color management API',['../a00072.html',1,'']]]
];
