var searchData=
[
  ['glossy',['GLOSSY',['../a00005.html#a852f0629069a83f4852b3edcd01cf60ea5af1a05cf55a29813f9fc99f37d17177',1,'BSDF']]]
];
