var a00022 =
[
    [ "Matte", "a00022.html#aedbb461240afd13d1ced507d4885fe85", null ],
    [ "evaluate", "a00022.html#a5b3254ffd73cd1f7f574868b10374bf8", null ],
    [ "m_kd", "a00022.html#aef31433f7cf6f9801c505caaa92d0f7c", null ]
];