var a00020 =
[
    [ "Light", "a00020.html#aeb5df09a25a32f19fdffa761268ba24f", null ],
    [ "Light", "a00020.html#aab4ed3906b9f59d5cf27ad83d75ad478", null ],
    [ "le", "a00020.html#a67501efbaeb33e1392fedb8b0d768ac8", null ],
    [ "pos", "a00020.html#a305715f1db3acf3dbd9dbd54baaa804e", null ],
    [ "m_le", "a00020.html#aca96943ae47693c6095184557457ce16", null ],
    [ "m_pos", "a00020.html#ab14e2ffc3b23df9e0b34d7223fc8f9b0", null ]
];