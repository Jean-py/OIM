var a00006 =
[
    [ "Camera", "a00006.html#a01f94c3543f56ede7af49dc778f19331", null ],
    [ "Camera", "a00006.html#ab64d39987eeb083cae664ba62f761967", null ],
    [ "ray_for_pixel", "a00006.html#a98275b6232248a9c1691cd9500d8134d", null ],
    [ "x_res", "a00006.html#afb6742de1f5a9bcbd80041485b5917eb", null ],
    [ "y_res", "a00006.html#a8206d3f96cc607fbd43037ef017defc2", null ],
    [ "m_center", "a00006.html#ae53d9660d1a67d909ef094224e86eda1", null ],
    [ "m_pos", "a00006.html#ac9581d4497bc0ebe59fa081af1e8c51d", null ],
    [ "m_x", "a00006.html#aa7bb54423b16f8840820a52dfa63e9e4", null ],
    [ "m_x_res", "a00006.html#ad3c5b17fe3da619d7ee0ee19fc3b584a", null ],
    [ "m_y", "a00006.html#a1d0af41f1c7b99e6e79dd59ae3b2ea07", null ],
    [ "m_y_res", "a00006.html#ad51ce627ba998a910c8e17684695bc26", null ],
    [ "m_z", "a00006.html#a9eb7e19474110ac1ed3e227ee6d46ab8", null ]
];