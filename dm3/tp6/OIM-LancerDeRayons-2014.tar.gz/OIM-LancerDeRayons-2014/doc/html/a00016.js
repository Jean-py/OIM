var a00016 =
[
    [ "Glossy", "a00016.html#a99190c0664503299f088fa4a1dd6f413", null ],
    [ "evaluate", "a00016.html#aa512c7e4d7e7e5f5ae05a3114aaf753e", null ],
    [ "m_ior", "a00016.html#a8880b98a31282d6021f06c4eed107bdf", null ],
    [ "m_kd", "a00016.html#a7319fa71529c0a331b645a47bbbee632", null ],
    [ "m_kr", "a00016.html#afc1d251e6699061003071c2272ccf78f", null ],
    [ "m_ks", "a00016.html#a9a0b07cf92e10a6df8cf965126dc831e", null ],
    [ "m_shininess", "a00016.html#abc34ff7e2ab53e4468b1660dfd72672e", null ]
];