var a00007 =
[
    [ "Color", "a00007.html#a9a742cbe9f9f4037f5d9f4e81a9b2428", null ],
    [ "Color", "a00007.html#a866f5b3f4192cdd953900b3bdae4b2cd", null ],
    [ "Color", "a00007.html#a63d27314877c0f737c4fe76612486cfa", null ],
    [ "Color", "a00007.html#a92a9f1af6b0e33aac1f46d348d241c52", null ],
    [ "avg", "a00007.html#ab43c458dc1c46ffc762b7e9cb726ef3e", null ],
    [ "is_zero", "a00007.html#addd9a00e50cad82c55c405c9683da443", null ],
    [ "operator*", "a00007.html#a9ac7755b39d4e96e843741a62bdba24e", null ],
    [ "operator*", "a00007.html#a53c38c4d10fe8f465cdc18843c8c7811", null ],
    [ "operator+", "a00007.html#a7128adc74f8de23b922a70eceea09ef0", null ],
    [ "operator[]", "a00007.html#ada85564386200034b6991cdf732e5fc8", null ],
    [ "operator*", "a00007.html#a925e7fe8e988d80b2f430ac498711a4d", null ],
    [ "m_comps", "a00007.html#acb389290a7593696678b1def98e35dfd", null ]
];