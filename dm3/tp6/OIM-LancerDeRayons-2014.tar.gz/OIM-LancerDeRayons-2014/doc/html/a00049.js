var a00049 =
[
    [ "FOND", "a00049.html#a6a6a4ff78925404dd197deea2cc78cb6", null ],
    [ "MOSAIC", "a00049.html#a0db4c6ecc60cb9b5c79a52c8b52d6fc6", null ],
    [ "QUADRILLAGE", "a00049.html#a9d973f199d48f70575a94f590b347573", null ],
    [ "compute_direct_lighting", "a00049.html#a9f1daa433c3bc9891cb1202a4e89080f", null ],
    [ "compute_image", "a00049.html#ab1d1ac9ba4ad1639618cfd7613fee95f", null ],
    [ "main", "a00049.html#ae66f6b31b5ad750f1fe042a706a4e3d4", null ],
    [ "make_textured_scene", "a00049.html#a322944f24b18d5647a07cefea27d8861", null ],
    [ "trace_ray", "a00049.html#a0bb032ac4d4d1b49ce014a54feed764a", null ]
];