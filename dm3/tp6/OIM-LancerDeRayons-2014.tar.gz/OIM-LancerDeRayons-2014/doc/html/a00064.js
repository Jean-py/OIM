var a00064 =
[
    [ "getTexel", "a00064.html#ad6c74e0d655725b60d1c0ac068664137", null ],
    [ "integrateTexture", "a00064.html#a79512e8201e923fec16ccc8a8d7113b2", null ],
    [ "interpolateTexture", "a00064.html#aa82c0e54572b2cc47433b2e7f00f13fc", null ],
    [ "prefilterTexture", "a00064.html#a2bbce8cb9f75d7bbfc5601b5cf0c1b01", null ]
];