var a00074 =
[
    [ "get_image_resolution", "a00074.html#ga0a694e21c663d5c72182c15e34118f23", null ],
    [ "save_image", "a00074.html#gaee5a58a341bc2053065b4fa8c8950577", null ],
    [ "save_png", "a00074.html#ga68bc73e2206f80129b14b4505d7ddc0b", null ],
    [ "set_pixel_color", "a00074.html#gacf909032cf0b1ef56a88bdfc416ac4ea", null ]
];