var a00009 =
[
    [ "CSGDifference", "a00009.html#adad1d79bc56124f95fefc7b0e20077ed", null ],
    [ "clip", "a00009.html#abb5077f37138af94f364e00810f83955", null ],
    [ "intersect", "a00009.html#a4df21af1e7d7a34ccd724c849de31cfc", null ],
    [ "m_a", "a00009.html#a91d8fc97a962cf2afc22e01a5ec2ce76", null ],
    [ "m_b", "a00009.html#a216c3a44f50db8b63262ead7a98ba96e", null ]
];