var a00021 =
[
    [ "Material", "a00021.html#a137e987401b63eb7c6c27c3e38bc74b5", null ],
    [ "evaluate", "a00021.html#abb68e80a020e81d0130b275203b1680c", null ],
    [ "getTextureColor", "a00021.html#ad292661deaf1ff67911e8f298717aa43", null ],
    [ "hasTexture", "a00021.html#a57ea70765a4884a2500ebb51359cc79d", null ],
    [ "setTexture", "a00021.html#af5b80bf73b7ea87a3d9d3855596be1f4", null ],
    [ "mTexture", "a00021.html#a956ffab8f7a6dfb4632d2c50e496db06", null ]
];