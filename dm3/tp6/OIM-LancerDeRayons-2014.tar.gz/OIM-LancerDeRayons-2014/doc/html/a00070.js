var a00070 =
[
    [ "add_light", "a00070.html#ga7338897b0e82076338fb7dd7cadeaddc", null ],
    [ "add_object", "a00070.html#gadf3f8ea1c8bf943db640af01230ed0f7", null ],
    [ "create_box", "a00070.html#ga97f60add9f9b7177df6c8f2f2372561a", null ],
    [ "create_cone", "a00070.html#ga27c1a3eeb2869e55865f2cc6d3e717f1", null ],
    [ "create_cylinder", "a00070.html#gabd60bd9dfe9afb36b127decf9145287d", null ],
    [ "create_glass_mat", "a00070.html#ga064ee1f6da1924df4e37334c456ea18f", null ],
    [ "create_glossy_mat", "a00070.html#ga29d1d8af09f26bf8a39980f456a18a10", null ],
    [ "create_matte_mat", "a00070.html#gad720b183f0a7c5b1d366a86fae48ff5e", null ],
    [ "create_metal_mat", "a00070.html#ga7e84d93db3d16480aa51e9d9cc16d843", null ],
    [ "create_plane", "a00070.html#gaf8b0ecdd64116491706ebede06c13b54", null ],
    [ "create_plastic_mat", "a00070.html#ga5e9b1752bc3635d8e03aeedce96f1378", null ],
    [ "create_sphere", "a00070.html#ga2da051b943f32009496f94737261c248", null ],
    [ "get_light", "a00070.html#gade62171a2f3b305905e5b0ada32357ff", null ],
    [ "make_default_scene", "a00070.html#ga5102ec4e0cd297fb1e649f5dde3bd029", null ],
    [ "nb_lights", "a00070.html#ga16d4353577e7adc824650320333c7245", null ],
    [ "set_camera", "a00070.html#gad67f595be55be0bc50b4ec08a9c74192", null ]
];