var a00072 =
[
    [ "add_color_color", "a00072.html#gaef9b6318d003356d86ac547b6bc2f57b", null ],
    [ "black", "a00072.html#gade20962f791f22292f6eb7f169d464e2", null ],
    [ "color_is_black", "a00072.html#ga8a9950fd49c3927a6b247f20c0f584cf", null ],
    [ "init_color", "a00072.html#ga8442f299f5a4fad5e1ffe8b54ce3a852", null ],
    [ "multiply_color_color", "a00072.html#ga2360109ceed6102f17ff17c573743395", null ]
];