var a00025 =
[
    [ "Plastic", "a00025.html#a277334a36838a4f095280ce928841821", null ],
    [ "evaluate", "a00025.html#a0ab6450feff5ca3f1f4e3527030e20cb", null ],
    [ "m_kd", "a00025.html#a6be31f8d2b046819d566e38d287540a1", null ],
    [ "m_ks", "a00025.html#a891ed62ed59f677887bd7515308cca2e", null ],
    [ "m_shininess", "a00025.html#a2de0658ce109791e5a0b85dc0ff3dcdf", null ]
];