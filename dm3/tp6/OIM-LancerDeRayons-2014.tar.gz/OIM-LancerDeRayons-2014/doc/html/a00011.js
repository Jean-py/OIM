var a00011 =
[
    [ "CSGUnion", "a00011.html#a1f0fe43e4a2ff171773c38f5a41e4a24", null ],
    [ "clip", "a00011.html#af10ef9b38d6f02403ccc1586bfd042ef", null ],
    [ "intersect", "a00011.html#acca00fa585a6bec21b20671df79fe030", null ],
    [ "m_a", "a00011.html#aef3bf2f349211b092622470700ca1ca0", null ],
    [ "m_b", "a00011.html#a020c272d5376e6fc150b236eae09fefb", null ]
];