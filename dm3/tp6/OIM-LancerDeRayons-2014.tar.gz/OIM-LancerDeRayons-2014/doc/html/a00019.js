var a00019 =
[
    [ "Isect", "a00019.html#ae4776bb9be2452fbe809e8bf94562d83", null ],
    [ "Isect", "a00019.html#ad353c6d622ef4337988a331188c0a024", null ],
    [ "bsdf", "a00019.html#ad175c0c1162ae8050132013c4578d4fe", null ],
    [ "dg", "a00019.html#a6709cddc48c0c8e2631c7b23437bd6ef", null ],
    [ "mat", "a00019.html#a2cc285e0c92beefcc990ba96bc0f8a6a", null ],
    [ "setBsdf", "a00019.html#ac37c0a40e869d82f176ad5e92b997744", null ],
    [ "m_bsdf", "a00019.html#a8b19d51ecb52fb18f353488779fd556e", null ],
    [ "m_dg", "a00019.html#a03db9423170cec42f816a5e855cb0a2c", null ],
    [ "m_mat", "a00019.html#af5e4ec5d51df98aed91cc006becadb38", null ]
];