var a00044 =
[
    [ "difference_of_intervals", "a00044.html#a405c977f6831f22f9b822f0a1a2a4bb7", null ],
    [ "intersection_of_intervals", "a00044.html#a26806eb167bb645a89e1b39f01dd5bca", null ],
    [ "union_of_intervals", "a00044.html#ac6b53e72e199766315087879f7d015e5", null ]
];