var a00023 =
[
    [ "Metal", "a00023.html#aef8edb45e960d983ac9871c3588932eb", null ],
    [ "evaluate", "a00023.html#a3c6190f266c9043c8a1cc157e9647780", null ],
    [ "m_kd", "a00023.html#a84853572681a66a2b9845232909fb4f7", null ],
    [ "m_kr", "a00023.html#a927d308e3b398a255711d3b3307c2c87", null ]
];