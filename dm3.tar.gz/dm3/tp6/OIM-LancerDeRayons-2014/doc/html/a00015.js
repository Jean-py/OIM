var a00015 =
[
    [ "Glass", "a00015.html#ab6ccfb3332ac7a27d4c01e6654ac9b9e", null ],
    [ "evaluate", "a00015.html#a94c040eef9f806af10a25f3bbdd78819", null ],
    [ "m_ior", "a00015.html#a88aec1f7d906f25842a3125fda1e3165", null ],
    [ "m_kr", "a00015.html#ab71ede273b7963bbddd35c44629646e1", null ],
    [ "m_kt", "a00015.html#a38f1463e4063a07e64e5aae0d5c041e6", null ]
];