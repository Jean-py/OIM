var a00073 =
[
    [ "direct_lighting", "a00073.html#ga3a215078ec8db08fc79e0a491bc61b59", null ],
    [ "isect_has_reflection", "a00073.html#gaf4ff7bddd9b295164491d5126289cd83", null ],
    [ "isect_has_refraction", "a00073.html#gaba7d4545b2466ae21efe827026358eec", null ],
    [ "reflect", "a00073.html#ga397536f562058dee83e3be0813324e82", null ],
    [ "refract", "a00073.html#ga1c7e1aae0ca65e600b252447bc817038", null ]
];