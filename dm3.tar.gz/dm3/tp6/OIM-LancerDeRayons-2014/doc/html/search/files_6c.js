var searchData=
[
  ['light_2ehpp',['light.hpp',['../a00048.html',1,'']]]
];
