var searchData=
[
  ['has_5freflection',['has_reflection',['../a00005.html#a770df55c2f2ba844764b341e93ea41f7',1,'BSDF']]],
  ['has_5frefraction',['has_refraction',['../a00005.html#aca1d179bc6d6a06b395f8768019cc4f0',1,'BSDF']]],
  ['hastexture',['hasTexture',['../a00021.html#a57ea70765a4884a2500ebb51359cc79d',1,'Material']]],
  ['height',['height',['../a00030.html#a0a5592fcf3a2270578880aed20c4bde0',1,'Texture']]]
];
