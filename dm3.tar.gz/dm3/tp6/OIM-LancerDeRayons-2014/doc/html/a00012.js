var a00012 =
[
    [ "Cylinder", "a00012.html#a01dc978cb576f834b9545e43d4dad2a2", null ],
    [ "Cylinder", "a00012.html#aa5eaa26636bec4e5b4200bf1e2493823", null ],
    [ "clip", "a00012.html#a39e9a7ebf491149b58fc079e250f18bb", null ],
    [ "computeCylindricalTexInfo", "a00012.html#a92147892ccb160276ef50997c1303ae2", null ],
    [ "computePlanarTexInfo", "a00012.html#adad45f440e3fa3b0d0f1f2d05495aeb3", null ],
    [ "fillCylindricalDiffGeom", "a00012.html#a2d585ce8b14de9e1611e0accc107e518", null ],
    [ "fillPlanarDiffGeom", "a00012.html#a177615c862c903affe4865063e2fb802", null ],
    [ "get_clip_points", "a00012.html#a646e440049ec43067444b2efa0c6b860", null ],
    [ "intersect", "a00012.html#aaf9bb0e9f800879eaa31070c9f7eb687", null ],
    [ "m_axis", "a00012.html#a5bb8e5f89492ea7b32c30af0f49e04a1", null ],
    [ "m_base", "a00012.html#a03599e6c41c277ed35de4da14c9cd886", null ],
    [ "m_length", "a00012.html#a5943bbe030c7c18f9e25f048c014e841", null ],
    [ "m_radius", "a00012.html#a4c3e3c6fc81ea1ad7e9ac678e58960dd", null ],
    [ "U", "a00012.html#ad00b72a832a896e630c3ef18b6ad61dc", null ],
    [ "V", "a00012.html#a83c7947702a9743b141dca395e5d6319", null ],
    [ "W", "a00012.html#ad9d0b915aac1186a6b7444cf06701c71", null ]
];