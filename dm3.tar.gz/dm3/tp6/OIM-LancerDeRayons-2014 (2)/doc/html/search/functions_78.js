var searchData=
[
  ['x',['x',['../a00031.html#a15a162a986b897ebd0bb74df056d99c5',1,'Vector3D']]],
  ['x_5fres',['x_res',['../a00006.html#afb6742de1f5a9bcbd80041485b5917eb',1,'Camera::x_res()'],['../a00017.html#a926a363fe861e5d0ac3a46cc89ecc0c4',1,'Image::x_res()']]]
];
