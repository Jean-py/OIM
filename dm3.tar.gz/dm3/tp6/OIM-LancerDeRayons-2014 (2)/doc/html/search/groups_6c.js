var searchData=
[
  ['lighting_20computation_20api',['Lighting computation API',['../a00073.html',1,'']]]
];
