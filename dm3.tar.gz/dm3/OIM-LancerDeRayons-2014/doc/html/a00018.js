var a00018 =
[
    [ "IntervalSet", "a00018.html#af81849627d07e0ccb903789545403ae6", null ],
    [ "add", "a00018.html#a5875b7222430d9be92a654db194d0d60", null ],
    [ "bounds", "a00018.html#a071811cdb02ba0cf2c05140bcf466927", null ],
    [ "difference_operator", "a00018.html#a9198fef85524577881942cf644e4d6b9", null ],
    [ "intersection_operator", "a00018.html#afab397d8b7684c651fb4e219b5586369", null ],
    [ "union_operator", "a00018.html#a877e525fbd78f4a34d51d3e22ea4ad87", null ],
    [ "m_bounds", "a00018.html#abeb31a403c3612613edd990c8a674bde", null ]
];