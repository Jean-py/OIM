var a00005 =
[
    [ "Model", "a00005.html#a852f0629069a83f4852b3edcd01cf60e", [
      [ "DIFFUSE", "a00005.html#a852f0629069a83f4852b3edcd01cf60eaa87f530394aa0ce82a30c78df742f433", null ],
      [ "BLINN_PHONG", "a00005.html#a852f0629069a83f4852b3edcd01cf60ea3b73141a0f09c8761912e2edd4189bed", null ],
      [ "GLOSSY", "a00005.html#a852f0629069a83f4852b3edcd01cf60ea5af1a05cf55a29813f9fc99f37d17177", null ],
      [ "PURE_REFL", "a00005.html#a852f0629069a83f4852b3edcd01cf60ea92e7ebf798d62551ba2d81f22bbd370e", null ],
      [ "FRESNEL", "a00005.html#a852f0629069a83f4852b3edcd01cf60eaa558f8550e4309f3ef5323b193fb43d6", null ]
    ] ],
    [ "BSDF", "a00005.html#a49adf3e02a71382167669b97263d6321", null ],
    [ "BSDF", "a00005.html#a269624a07342f9d2ea5c9c71b10d0797", null ],
    [ "evaluate", "a00005.html#a89754b621acdd482f06a0b11c0ecdf3a", null ],
    [ "getIor", "a00005.html#a40748b3fdb9139f3819660637a127172", null ],
    [ "has_reflection", "a00005.html#a770df55c2f2ba844764b341e93ea41f7", null ],
    [ "has_refraction", "a00005.html#aca1d179bc6d6a06b395f8768019cc4f0", null ],
    [ "init_blinn_phong", "a00005.html#aaa834a440a78af61ef56984c3fcc79f8", null ],
    [ "init_diffuse", "a00005.html#a9dd8bf6529b8cc159f570600bbee872c", null ],
    [ "init_fresnel", "a00005.html#a654638fb3e8f649825aea76416fe5a6d", null ],
    [ "init_glossy", "a00005.html#abc0d4c3f673c7eab346a625678cec31f", null ],
    [ "init_pure_refl", "a00005.html#a5721ae7c30efb1e90beb7ea6b49d9ca4", null ],
    [ "reflect_dir", "a00005.html#a0c1293b4a879f5797f9befcaef2c4c99", null ],
    [ "refract_dir", "a00005.html#a072b04d8fc38b94911e023dcb3a0c28f", null ],
    [ "m_ior", "a00005.html#aad7ad5ebee66c23d47d1025d96501cca", null ],
    [ "m_kd", "a00005.html#abd4f5c45b5d74fe04f9f6e34284304e4", null ],
    [ "m_kr", "a00005.html#af0565c84cf33ca5c9f56310ddd0d5e0f", null ],
    [ "m_ks", "a00005.html#ac9a613ac0a7859f05dcb44ee250065c8", null ],
    [ "m_kt", "a00005.html#acf9099c59d7589cbf0cc01c74f1de6c1", null ],
    [ "m_model", "a00005.html#acdf1f70e649aed91eb0196f978d17ff4", null ],
    [ "m_normal", "a00005.html#a34f10e0396208521fbe1698804589234", null ],
    [ "m_shininess", "a00005.html#ad3982e7ed366dca25cd3125b80a1001f", null ]
];