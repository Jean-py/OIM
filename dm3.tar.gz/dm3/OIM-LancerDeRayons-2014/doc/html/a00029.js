var a00029 =
[
    [ "Sphere", "a00029.html#a890a63ff583cb88e7ec4e840b4ef5eb9", null ],
    [ "Sphere", "a00029.html#a8727e5ea0f74d523eadafc8114648014", null ],
    [ "clip", "a00029.html#ac78e1c4b2d124b9df40f3688231f5b45", null ],
    [ "computeTexInfo", "a00029.html#a67d69832e0316a755ad2b6a12da719c0", null ],
    [ "intersect", "a00029.html#acb1c5b063489f881872e6faf155c4c18", null ],
    [ "m_center", "a00029.html#ae06d95adb9b47f56d62ec3eab9ba2551", null ],
    [ "m_radius", "a00029.html#a1faee6c9b6e62abf0d35cc87a1894b61", null ]
];