var searchData=
[
  ['g_5fcamera',['g_camera',['../a00057.html#a8ea4ea2eb2676e84509a7f4c5ce43dda',1,'raytracing.cpp']]],
  ['g_5fp_5fimg',['g_p_img',['../a00057.html#adcfc067701db6262297c2bbec15927cd',1,'raytracing.cpp']]],
  ['g_5fscene',['g_scene',['../a00057.html#aab84ef508ba02254f00c7cd02f420b28',1,'raytracing.cpp']]]
];
