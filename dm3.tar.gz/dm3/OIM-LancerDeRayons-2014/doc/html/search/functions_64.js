var searchData=
[
  ['dddx',['dDdx',['../a00013.html#a6ffec5fe0ac1ecc780b472a910d2017a',1,'Diff_Geom::dDdx()'],['../a00027.html#a208d83f46a83c0c1c2646557f20528b6',1,'Ray::dDdx()']]],
  ['dddy',['dDdy',['../a00013.html#ae63247e057e0fa7d7517671d66181b7c',1,'Diff_Geom::dDdy()'],['../a00027.html#a1e7203abf3bf883e9a5e739125e85973',1,'Ray::dDdy()']]],
  ['depth',['depth',['../a00027.html#a5aca258edd0f8365436fbe2ff5305cd2',1,'Ray']]],
  ['dg',['dg',['../a00019.html#a6709cddc48c0c8e2631c7b23437bd6ef',1,'Isect']]],
  ['diff_5fgeom',['Diff_Geom',['../a00013.html#a360263952c54068d6661635cdd05f2d0',1,'Diff_Geom::Diff_Geom()'],['../a00013.html#ae756f7a5a0dc61f313053eb2722d51ce',1,'Diff_Geom::Diff_Geom(const Vector3D &amp;pos_, const Vector3D &amp;normal_, const Vector3D &amp;dndx_, const Vector3D &amp;dndy_, float t, const Vector3D &amp;dPdx_, const Vector3D &amp;dPdy_, const Vector3D &amp;dDdx_, const Vector3D &amp;dDdy_, float u, float v, const Vector3D &amp;dTdx_, const Vector3D &amp;dTdy_, bool in)']]],
  ['difference_5fof_5fintervals',['difference_of_intervals',['../a00044.html#a405c977f6831f22f9b822f0a1a2a4bb7',1,'difference_of_intervals(Bound *a, int size_a, Bound *b, int size_b, Bound *res, int *size_res):&#160;intervaloperators.cpp'],['../a00045.html#a405c977f6831f22f9b822f0a1a2a4bb7',1,'difference_of_intervals(Bound *a, int size_a, Bound *b, int size_b, Bound *res, int *size_res):&#160;intervaloperators.cpp']]],
  ['difference_5foperator',['difference_operator',['../a00018.html#a9198fef85524577881942cf644e4d6b9',1,'IntervalSet']]],
  ['dir',['dir',['../a00027.html#a9bfb39f0ff5a7a2330ef9749b8e97e17',1,'Ray']]],
  ['direct_5flighting',['direct_lighting',['../a00073.html#ga3a215078ec8db08fc79e0a491bc61b59',1,'direct_lighting(Ray ray_, Isect isect_, Light *light_):&#160;raytracing.cpp'],['../a00073.html#ga3a215078ec8db08fc79e0a491bc61b59',1,'direct_lighting(Ray ray_, Isect isect_, Light *light_):&#160;raytracing.cpp']]],
  ['dndx',['dNdx',['../a00013.html#a31611ca29f29bc7c000ddcdd483e8177',1,'Diff_Geom']]],
  ['dndy',['dNdy',['../a00013.html#a5957467c675f5066939dc92bea0ea738',1,'Diff_Geom']]],
  ['dot',['dot',['../a00031.html#a293698c2fcdc50968fa63e125120bd61',1,'Vector3D']]],
  ['dpdx',['dPdx',['../a00013.html#a210b806c862ecf086982cd52189f900a',1,'Diff_Geom::dPdx()'],['../a00027.html#a1dca76b0cd170aecbf8a2b53855cb0a9',1,'Ray::dPdx()']]],
  ['dpdy',['dPdy',['../a00013.html#aea9c1cfd45720b9c689198653eb1136d',1,'Diff_Geom::dPdy()'],['../a00027.html#aae11d929741f134ede07bf6773fc5a9f',1,'Ray::dPdy()']]],
  ['dtdx',['dTdx',['../a00013.html#afccf9a7535b017156a84237ef9bd3f71',1,'Diff_Geom']]],
  ['dtdy',['dTdy',['../a00013.html#aebdb7ea0d43eb3f84fdb8ffcf9c37c5b',1,'Diff_Geom']]]
];
