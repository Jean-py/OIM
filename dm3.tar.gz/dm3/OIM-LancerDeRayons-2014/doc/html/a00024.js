var a00024 =
[
    [ "Plane", "a00024.html#aa174951fb18c608b8d29cfede77cc0ba", null ],
    [ "clip", "a00024.html#ab07fd72491019dfdce875eaa677ba18f", null ],
    [ "intersect", "a00024.html#a8972d45fdd4d58cc736ce779da8e000a", null ],
    [ "settangent", "a00024.html#a7c0ba60dc93567610573fe9b1c0fe26c", null ],
    [ "m_binormal", "a00024.html#ad83c5490f95176a8830ebee571b7cb83", null ],
    [ "m_normal", "a00024.html#af2b63a575649b495d453e2adebb277c2", null ],
    [ "m_offset", "a00024.html#a0361abf7879d206c9ae2917bb7be767e", null ],
    [ "m_pos", "a00024.html#a649d9698f820cc0187ce302771efc988", null ],
    [ "m_tangent", "a00024.html#ab5f9e18cb10806b310eb5c9eb64d0b3e", null ]
];