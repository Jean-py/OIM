var a00071 =
[
    [ "camera_ray", "a00071.html#ga8cb8aef586b50a39b449ebb804acee60", null ],
    [ "intersect_scene", "a00071.html#gaa971dcbc0062c359e8464f84662b0bd4", null ],
    [ "ray_depth", "a00071.html#gac588aae49805e61713de3d50ce6f04cd", null ],
    [ "ray_importance", "a00071.html#ga69e5c6dd970eec59a78918a79badfbc8", null ],
    [ "test_visibility", "a00071.html#gafdd7145eb904844de4296af68d315e39", null ]
];