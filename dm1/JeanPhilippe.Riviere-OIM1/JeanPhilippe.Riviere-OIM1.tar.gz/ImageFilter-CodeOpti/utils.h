#ifndef __UTILS_H__
#define __UTILS_H__


int min(int a, int b);
int max(int a, int b);


#endif

