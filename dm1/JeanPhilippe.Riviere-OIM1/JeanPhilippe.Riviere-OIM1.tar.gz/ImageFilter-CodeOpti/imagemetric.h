#include "image.h"

#ifndef __IMAGEMETRIC__
#define __IMAGEMETRIC__

float compare_images(image *ref, image *comp, int filtersize);

#endif
