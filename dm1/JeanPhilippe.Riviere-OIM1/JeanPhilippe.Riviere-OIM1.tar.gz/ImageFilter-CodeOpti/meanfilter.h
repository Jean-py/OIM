#include "image.h"

#ifndef __MEANFILTER__
#define __MEANFILTER__

void meanfilter(image *img, image *out, int filtersize);

#endif
